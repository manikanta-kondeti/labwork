<?php
if($_POST['user_check2']!=2)
{
	header('location: ./home.php');
}
else
{
?>

<!Doctype>
<html>
<head><title>ShpFile</title></head>
<body>
<h1 align="center">Multiple ShpViewer</h1>
</body>
</html>

<?php
}
?>
